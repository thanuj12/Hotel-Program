package arrays;
import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileWriter;
public class HotelExample {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String roomName;
        int roomNum;

        long cNo;
        long cNo2=0;
        long div;
        String name;
        String choice;
        String choice2 = "Y";
        String[] hotel = new String[8];
        String[] Name1 = new String[8];
        String[] Name2 = new String[8];
        int [] guestNo = new int[8];
        long [] creditCNo = new long[8];
        //for (int x = 0; x < 6; x++ ) hotel[x] = ""; //initialise
        initialise(hotel,Name1,Name2); //better to initialise in a procedure
        while (choice2.equals("Y")) {
            Menu();
            System.out.print("Enter your choice: ");
            choice = input.next().toUpperCase();
            switch (choice) {
                case "V":
                    for (int x = 0; x < 8; x++) {
                        if (hotel[x].equals("e")) {
                            System.out.println("---------------------------------------------");
                            System.out.println("room " + x + " is empty");
                            System.out.println("---------------------------------------------");
                        } else {
                            System.out.println("---------------------------------------------");
                            System.out.println("Room " + x + " is occupied by : " + hotel[x]);
                            System.out.println("No of Guests in room " + x + " : " + guestNo[x]);
                            System.out.println("First name of the paying guest : " + Name1[x]);
                            System.out.println("Surname of the paying guest : " + Name2[x]);
                            System.out.println("Credit card Number of the paying guest : " + creditCNo[x]);
                            System.out.println("---------------------------------------------");
                        }
                    }
                    break;
                case "A":
                    String s;
                    System.out.println("Enter room number (0-7) or 8 to stop:");
                    roomNum = input.nextInt();
                    if (roomNum == 8) {
                        System.out.println("Thank You. You are about to exit the program");
                        break;
                    } else if (hotel[roomNum].equals("e")) {
                        System.out.println("Enter name for room " + roomNum + " :");
                        roomName = input.next().toUpperCase();
                        hotel[roomNum] = roomName;
                        System.out.println("Enter number of guests in the room: ");
                        int no = input.nextInt();
                        guestNo[roomNum] = no;
                        System.out.println("Enter first name of the paying guest: ");
                        String fName = input.next().toUpperCase();
                        Name1[roomNum] = fName;
                        System.out.println("Enter surname of the paying guest: ");
                        String sName = input.next().toUpperCase();
                        Name2[roomNum] = sName;

                        int count2 = 1;
                        while (count2 != 12) {
                            count2 = 1;
                            System.out.println("Enter you 12 digit credit card no: ");
                            cNo = input.nextLong();
                            cNo2 = cNo;
                            while (cNo > 1) {
                                div = cNo / 10;
                                cNo = div;
                                count2 += 1;
                            }
                            if (count2 != 12) {
                                System.out.println("Invalid number of digits entered for credit card number. Please try again.");
                            }
                        }
                        creditCNo[roomNum] = cNo2;
                        System.out.println("Thank You. Room " + roomNum + " is occupied by " + roomName);
                    } else {
                        s = hotel[roomNum];
                        System.out.println("This room is already occupied by " + s + ". PLEASE CHOOSE ANOTHER ROOM.");
                    }

                    break;
                case "E":
                    for (int x = 0; x < 8; x++) {
                        if (hotel[x].equals("e")) {
                            System.out.println("room " + x + " is empty");
                        }
                    }
                    break;
                case "D":
                    System.out.println("Enter the room in which you want to delete a customer : ");
                    roomNum = input.nextInt();
                    if (hotel[roomNum].equals("e")) {
                        System.out.println("The room number is already empty");
                    } else {
                        hotel[roomNum] = "e";
                        guestNo[roomNum] = 0;
                        Name1[roomNum] = " ";
                        Name2[roomNum] = " ";
                        creditCNo[roomNum] = 0;
                        System.out.println("Deleted customer from room " + roomNum + " successfully");
                    }
                    break;
                case "F":
                    System.out.println("Enter the customer name to find room: ");
                    name = input.next().toUpperCase();
                    boolean isFound = false;
                    for (int x = 0; x < 8; x++) {
                        if (hotel[x].equals(name)) {
                            System.out.println("Room Found. This particular customer is in room " + x);
                            isFound = true;
                        }
                    }
                    if (!isFound) {
                        System.out.println("Customer not found.");
                    }

                break;
                case "S":
                    try {
                        File myObj = new File("HOTEL.txt");
                        String newLine = System.getProperty("line.separator");
                        if (myObj.createNewFile()) {
                            System.out.println("File created: " + myObj.getName());
                        } else {
                            System.out.println("File already exists.");
                        }
                        FileWriter myWriter = new FileWriter("HOTEL.txt");
                        for (int x = 0; x < 8; x++) {
                            myWriter.write(hotel[x] + newLine);
                        }
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    try {
                        File myObj = new File("GUEST.txt");
                        String newLine = System.getProperty("line.separator");
                        if (myObj.createNewFile()) {
                            System.out.println("File created: " + myObj.getName());
                        } else {
                            System.out.println("File already exists.");
                        }
                        FileWriter myWriter = new FileWriter("GUEST.txt");
                        for (int x = 0; x < 8; x++) {
                            myWriter.write(guestNo[x] + newLine);
                        }
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    try {
                        File myObj = new File("FIRSTNAMES.txt");
                        String newLine = System.getProperty("line.separator");
                        if (myObj.createNewFile()) {
                            System.out.println("File created: " + myObj.getName());
                        } else {
                            System.out.println("File already exists.");
                        }
                        FileWriter myWriter = new FileWriter("FIRSTNAMES.txt");
                        for (int x = 0; x < 8; x++) {
                            myWriter.write(Name1[x] + newLine);
                        }
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    try {
                        File myObj = new File("SURNAMES.txt");
                        String newLine = System.getProperty("line.separator");
                        if (myObj.createNewFile()) {
                            System.out.println("File created: " + myObj.getName());
                        } else {
                            System.out.println("File already exists.");
                        }
                        FileWriter myWriter = new FileWriter("SURNAMES.txt");
                        for (int x=0; x<8; x++) {
                                myWriter.write(Name2[x] + newLine);
                            }
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    try {
                        File myObj = new File("CREDIT_CARD.txt");
                        String newLine = System.getProperty("line.separator");
                        if (myObj.createNewFile()) {
                            System.out.println("File created: " + myObj.getName());
                        } else {
                            System.out.println("File already exists.");
                        }
                        FileWriter myWriter = new FileWriter("CREDIT_CARD.txt");
                        for (int x=0; x<8; x++) {
                            myWriter.write(creditCNo[x] + newLine);
                        }
                        myWriter.close();
                        System.out.println("Successfully wrote to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                case "L":
                    try {
                        int x=0;
                        File myObj = new File("HOTEL.txt");
                        Scanner myReader = new Scanner(myObj);
                        while (myReader.hasNextLine()) {
                            String data = myReader.nextLine();
                            hotel[x]=data;
                            x++;
                        }
                        System.out.println("Loaded successfully");
                        myReader.close();
                    } catch (FileNotFoundException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    try {
                        int x=0;
                        File myObj = new File("GUEST.txt");
                        Scanner myReader = new Scanner(myObj);
                        while (myReader.hasNextInt()) {
                            int data = myReader.nextInt();
                            guestNo[x]=data;
                            x++;
                        }
                        System.out.println("Loaded successfully");
                        myReader.close();
                    } catch (FileNotFoundException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    try {
                        int x=0;
                        File myObj = new File("FIRSTNAMES.txt");
                        Scanner myReader = new Scanner(myObj);
                        while (myReader.hasNextLine()) {
                            String data = myReader.nextLine();
                            Name1[x]=data;
                            x++;
                        }
                        System.out.println("Loaded successfully");
                        myReader.close();
                    } catch (FileNotFoundException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    try {
                        int x=0;
                        File myObj = new File("SURNAMES.txt");
                        Scanner myReader = new Scanner(myObj);
                        while (myReader.hasNextLine()) {
                            String data = myReader.nextLine();
                            Name2[x]=data;
                            x++;
                        }
                        System.out.println("Loaded successfully");
                        myReader.close();
                    } catch (FileNotFoundException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                    try {
                        int x=0;
                        File myObj = new File("CREDIT_CARD.txt");
                        Scanner myReader = new Scanner(myObj);
                        while (myReader.hasNextLong()) {
                            long data = myReader.nextLong();
                            creditCNo[x]=data;
                            x++;
                        }
                        System.out.println("Loaded successfully");
                        myReader.close();
                    } catch (FileNotFoundException e) {
                        System.out.println("An error occurred.");
                        e.printStackTrace();
                    }
                case "O":
                    int count = 0;
                    for (int x = 0; x < 8; x++) {
                        if (!(hotel[x].equals("e"))) {
                            count += 1;
                        }
                    }
                    int c = 0;
                    String[] alphabet = new String[count];
                    for (int x = 0; x < 8; x++) {
                        if (!(hotel[x].equals("e"))) {
                            alphabet[c] = hotel[x];
                            c += 1;
                        }
                    }
                    boolean isSwapped = true;
                    while (isSwapped) {
                        isSwapped = false;
                        for (int i = 0; i < alphabet.length - 1; i++) {
                            if (alphabet[i].compareToIgnoreCase(alphabet[i + 1]) > 0) {
                                String temp = alphabet[i + 1];
                                alphabet[i + 1] = alphabet[i];
                                alphabet[i] = temp;
                                isSwapped = true;
                            }
                        }

                    }
                    for (String value : alphabet) {
                        System.out.println(value);
                    }

                    break;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
             do {
                System.out.println("Do you want to choose another option from the menu?");
                System.out.println("'Y' for Yes or 'N' for No");
                choice2 = input.next().toUpperCase();
                 if (choice2.equals("N")) {
                     System.out.println("Thank You. You are about to exit the program");
                     break;
                 }
            }while (!(choice2.equals("Y")));

        }
    }
    private static void initialise (String[]hotel, String[]Name1, String[]Name2){
        for (int x = 0; x < 8; x++) {
            hotel[x] = "e";
        }
        Arrays.fill(Name1, "empty");
        Arrays.fill(Name2, "empty");
    }





    private static void Menu() {
        System.out.println("Enter 'A' to add a customer to a room");
        System.out.println("Enter 'V' to view all rooms");
        System.out.println("Enter 'E' to display empty rooms ");
        System.out.println("Enter 'D' to delete customer from room ");
        System.out.println("Enter 'F' Find room from customer name");
        System.out.println("Enter 'S' Store program data into file");
        System.out.println("Enter 'L' Load program data from file");
        System.out.println("Enter 'O' View guests Ordered alphabetically by name");
    }
}
