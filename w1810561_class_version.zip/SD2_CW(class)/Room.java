package arrays;

public class Room {
    public String hotelName;
    public Person person;

    public Room(String hotelName, Person person){
        this.hotelName = hotelName;
        this.person = person;
    }

}
