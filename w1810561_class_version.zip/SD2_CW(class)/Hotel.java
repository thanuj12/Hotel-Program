package arrays;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
public class Hotel {
    public static Scanner input = new Scanner(System.in);
    public static Room [] hotel = new Room[8];
    public static String choice2 = "Y";
    public static Person [] guestNo = new Person[8];
    public static Person [] Name1 = new Person[8];
    public static Person [] Name2 = new Person[8];
    public static Person [] creditCNo = new Person[8];
    public static ArrayList<String> WaitingList = new ArrayList<>();

    public static String menu(){
        System.out.println("Enter 'A' to add a customer to a room");
        System.out.println("Enter 'V' to view all rooms");
        System.out.println("Enter 'E' to display empty rooms ");
        System.out.println("Enter 'D' to delete customer from room ");
        System.out.println("Enter 'F' Find room from customer name");
        System.out.println("Enter 'S' Store program data into file");
        System.out.println("Enter 'L' Load program data from file");
        System.out.println("Enter 'O' View guests Ordered alphabetically by name");
        System.out.println("Enter your choice: ");
        return input.next().toUpperCase();
    }

    public static void addRoom() {
        int a = 0;
        for (int i = 0; i < 8; i++) {
            if (!(hotel[i].hotelName.equals("e"))) {
                a += 1;
            }
        }
        if (a == 8) {
            System.out.println("Dear Customer, all our rooms are currently full. You will be added to our waiting list due to shortage of rooms. Sorry for the inconvenience caused. ");
            System.out.println("Please enter your name to add in the waiting list: ");
            WaitingList.add(input.next().toUpperCase());
        } else {
            System.out.println("Enter room number (0-7) or 8 to stop:");
            int roomNum = input.nextInt();
            if (roomNum == 8) {
                System.out.println("Thank You. You are about to exit the program");

            } else if (hotel[roomNum].hotelName.equals("e")) {
                System.out.println("Enter name for room " + roomNum + " :");
                String roomName = input.next().toUpperCase();
                System.out.println("Enter number of guests in the room: ");
                int no = input.nextInt();
                guestNo[roomNum].guestCount = no;
                System.out.println("Enter first name of the paying guest: ");
                String fName = input.next().toUpperCase();
                Name1[roomNum].fName = fName;
                System.out.println("Enter surname of the paying guest: ");
                String sName = input.next().toUpperCase();
                Name2[roomNum].sName = sName;

                int count2 = 1;
                long cNo2 = 0;
                while (count2 != 12) {
                    count2 = 1;
                    System.out.println("Enter you 12 digit credit card no: ");
                    long cNo = input.nextLong();
                    cNo2 = cNo;
                    long div;
                    while (cNo > 1) {
                        div = cNo / 10;
                        cNo = div;
                        count2 += 1;
                    }
                    if (count2 != 12) {
                        System.out.println("Invalid number of digits entered for credit card number. Please try again.");
                    }
                }
                creditCNo[roomNum].cNo = cNo2;
                System.out.println("Thank You. Room " + roomNum + " is occupied by " + roomName);
                hotel[roomNum] = new Room(roomName, new Person(no, fName, sName, cNo2));

            } else {

                System.out.println("This room is already occupied by " + hotel[roomNum] + ". PLEASE CHOOSE ANOTHER ROOM.");
            }
        }
        for (String s : WaitingList) {
            System.out.println(s);
        }
    }
    public static void viewAllRooms(){
        for (int x = 0; x < 8; x++) {
            if (hotel[x].hotelName.equals("e")) {
                System.out.println("room " + x + " is empty");
            } else {
                System.out.println("---------------------------------------------");
                System.out.println("Room " + x + " is occupied by : " + hotel[x].hotelName);
                System.out.println("No of Guests in room " + x + " : " + guestNo[x].guestCount);
                System.out.println("First name of the paying guest : " + Name1[x].fName);
                System.out.println("Surname of the paying guest : " + Name2[x].sName);
                System.out.println("Credit card Number of the paying guest : " + creditCNo[x].cNo);
                System.out.println("---------------------------------------------");
            }
        }
    }
    public static void emptyRooms(){
        for (int x = 0; x < 8; x++) {
            if (hotel[x].hotelName.equals("e")) {
                System.out.println("room " + x + " is empty");
            }
        }
    }
    public static void deleteRooms(){
        System.out.println("Enter the room in which you want to delete a customer : ");
        int roomNum = input.nextInt();
        if (hotel[roomNum].hotelName.equals("e")) {
            System.out.println("The room number is already empty");
        } else {
            int a = 0;
            for (int i = 0; i < 8; i++) {
                if (!(hotel[i].hotelName.equals("e"))) {
                    a += 1;
                }
            }
            hotel[roomNum] = new Room("e", new Person(0, " ", " ", 0));
            System.out.println("Deleted customer from room " + roomNum + " successfully");

            if (a == 8 && !(WaitingList.isEmpty())) {
                hotel[roomNum].hotelName = WaitingList.get(0);
                WaitingList.remove(0);
                System.out.println("You will be added to room " + roomNum + "shortly");
                System.out.println("Enter number of guests in the room: ");
                int no = input.nextInt();
                guestNo[roomNum].guestCount = no;
                System.out.println("Enter first name of the paying guest: ");
                String fName = input.next().toUpperCase();
                Name1[roomNum].fName = fName;
                System.out.println("Enter surname of the paying guest: ");
                String sName = input.next().toUpperCase();
                Name2[roomNum].sName = sName;

                int count2 = 1;
                long cNo2 = 0;
                while (count2 != 12) {
                    count2 = 1;
                    System.out.println("Enter you 12 digit credit card no: ");
                    long cNo = input.nextLong();
                    cNo2 = cNo;
                    long div;
                    while (cNo > 1) {
                        div = cNo / 10;
                        cNo = div;
                        count2 += 1;
                    }
                    if (count2 != 12) {
                        System.out.println("Invalid number of digits entered for credit card number. Please try again.");
                    }
                }


                System.out.println("Thank You. Room " + roomNum + " is occupied by " + hotel[roomNum].hotelName);
                guestNo[roomNum].guestCount = no;
                Name1[roomNum].fName = fName;
                Name2[roomNum].sName = sName;
                creditCNo[roomNum].cNo = cNo2;
            }
        }
    }
    public static void findRooms(){
        boolean isFound=false;
        System.out.println("Enter the customer name to find room: ");
        String name = input.next().toUpperCase();
        for (int x = 0; x < 8; x++) {
            if (hotel[x].hotelName.equals(name)) {
                System.out.println("Room Found. This particular customer is in room " + x);
                isFound=true;
            }
        }if (!isFound){
            System.out.println("Customer not found.");
        }
    }
    public static void storeData(){
        try {
            File myObj = new File("HOTEL.txt");
            String newLine = System.getProperty("line.separator");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
            FileWriter myWriter = new FileWriter("HOTEL.txt");
            for (int x = 0; x < 8; x++) {
                myWriter.write(hotel[x].hotelName + newLine);
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            File myObj = new File("GUEST.txt");
            String newLine = System.getProperty("line.separator");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
            FileWriter myWriter = new FileWriter("GUEST.txt");
            for (int x = 0; x < 8; x++) {
                myWriter.write(guestNo[x].guestCount + newLine);
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            File myObj = new File("FIRSTNAMES.txt");
            String newLine = System.getProperty("line.separator");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
            FileWriter myWriter = new FileWriter("FIRSTNAMES.txt");
            for (int x = 0; x < 8; x++) {
                myWriter.write(Name1[x].fName + newLine);
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            File myObj = new File("SURNAMES.txt");
            String newLine = System.getProperty("line.separator");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
            FileWriter myWriter = new FileWriter("SURNAMES.txt");
            for (int x = 0; x < 8; x++) {
                myWriter.write(Name2[x].sName + newLine);
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            File myObj = new File("CREDIT_CARDS.txt");
            String newLine = System.getProperty("line.separator");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }
            FileWriter myWriter = new FileWriter("CREDIT_CARDS.txt");
            for (int x = 0; x < 8; x++) {
                myWriter.write(creditCNo[x].cNo + newLine);
            }
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public static void loadData() {
        try {
            int x=0;
            File myObj = new File("HOTEL.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                hotel[x].hotelName=data;
                x++;
            }
            System.out.println("Loaded successfully");
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            int x=0;
            File myObj = new File("GUEST.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextInt()) {
                int data = myReader.nextInt();
                guestNo[x].guestCount=data;
                x++;
            }
            System.out.println("Loaded successfully");
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            int x=0;
            File myObj = new File("FIRSTNAMES.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                Name1[x].fName=data;
                x++;
            }
            System.out.println("Loaded successfully");
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            int x=0;
            File myObj = new File("SURNAMES.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                Name2[x].sName=data;
                x++;
            }
            System.out.println("Loaded successfully");
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            int x=0;
            File myObj = new File("CREDIT_CARDS.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLong()) {
                long data = myReader.nextLong();
                creditCNo[x].cNo=data;
                x++;
            }
            System.out.println("Loaded successfully");
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public static void nameOrder(){
        int count = 0;
        for (int x = 0; x < 8; x++) {
            if (!(hotel[x].hotelName.equals("e"))) {
                count += 1;
            }
        }
        int c = 0;
        String[] alphabet = new String[count];
        for (int x = 0; x < 8; x++) {
            if (!(hotel[x].hotelName.equals("e"))) {
                alphabet[c] = String.valueOf(hotel[x].hotelName);
                c += 1;
            }
        }
        boolean isSwapped = true;
        while (isSwapped) {
            isSwapped = false;
            for (int i = 0; i < alphabet.length - 1; i++) {
                if (alphabet[i].compareToIgnoreCase(alphabet[i + 1]) > 0) {
                    String temp = alphabet[i + 1];
                    alphabet[i + 1] = alphabet[i];
                    alphabet[i] = temp;
                    isSwapped = true;
                }
            }

        }
        for (String value : alphabet) {
            System.out.println(value);
        }

    }
    public static void initialise(Room[] hotel){
        for (int x = 0; x < 8; x++) {
            hotel[x] = new Room("e", new Person(0, " ", " ", 0));
        }
        for (int i = 0; i < 8; i++) {
            Name1[i]=new Person(0,"empty","",0);
            Name2[i]=new Person(0,"","empty",0);
            guestNo[i]=new Person(0,"","",0);
            creditCNo[i]=new Person(0,"","",0);
        }
    }
    public static void main(String[] args) {
        initialise(hotel);
        while (choice2.equals("Y")) {
            String choice =  menu();
            switch (choice) {
                case "A":
                    addRoom();
                    break;
                case "V":
                    viewAllRooms();
                    break;
                case "E":
                    emptyRooms();
                    break;
                case "D":
                    deleteRooms();
                    break;
                case "F":
                    findRooms();
                    break;
                case "S":
                    storeData();
                    break;
                case "L":
                    loadData();
                    break;
                case "O":
                    nameOrder();
                    break;
                default:
                    System.out.println("Invalid Choice");

            }
            do {
                System.out.println("Do you want to choose another option from the menu?");
                System.out.println("'Y' for Yes or 'N' for No");
                choice2 = input.next().toUpperCase();
                if (choice2.equals("N")) {
                    System.out.println("Thank You. You are about to exit the program");
                    break;
                }
            } while (!(choice2.equals("Y")));

        }
    }
}
