package arrays;

public class Person {
    public int guestCount;
    public String fName;
    public String sName;
    public long cNo;

    public Person(int guestCount, String fName, String sName, long cNo){
        this.guestCount = guestCount;
        this.fName = fName;
        this.sName = sName;
        this.cNo = cNo;
    }


}
